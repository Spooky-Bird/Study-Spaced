
# Study Spaced

Spaced repitition study tool created for U3&4 Software Development


## Display
To ensure the program's ui displays correctly, please change your computers display settings as follows
- Set display scale to 100%
- Enable bookmarks bar on chrome

## View online

The project is hosted at

```bash
  http://studyspaced-001-site1.htempurl.com/

```
To gain access to this site use following login credentials when prompted
| Username | 11193129    |
| :-------- | :------- |
| Password | 60-dayfreetrial | 
